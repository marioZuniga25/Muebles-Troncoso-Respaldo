Foundation Datepicker
=====================

**Feel free to contribute! Fork, modify, and send me a pull request.**

EXAMPLES AND DOCS available at http://foundation-datepicker.peterbeno.com

A note on forking:
-------------------
**By forking this project you hereby grant permission for any commits to your fork to be merged back into this repository and, with attribution, be released under the terms of the Apache License.**

Issues
-------------------
Before you submit a new issue, please check closed (maybe also open) issues [here](https://github.com/najlepsiwebdesigner/foundation-datepicker/issues?q=is%3Aissue+is%3Aclosed), maybe your problem was solved already. Thanks!
